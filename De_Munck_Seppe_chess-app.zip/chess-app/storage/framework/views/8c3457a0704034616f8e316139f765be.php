<!-- filepath: /c:/chessApp/cloudtaak_chessapp/chess-app/resources/views/page1.blade.php -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page 1</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <style>
        /* Optional: Additional styling for better table appearance */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #333;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .success-message {
            color: green;
            margin-top: 20px;
        }
        .error-messages {
            color: red;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Chess App</h1>
    </header>
    <div class="container">
        <h2>Search Player Games</h2>
        <form action="<?php echo e(route('page1')); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <input type="text" name="player" placeholder="Enter player name" required>
            <button type="submit">Search</button>
        </form>

        <!-- Display Error Messages -->
        <?php if($errors->any()): ?>
            <div class="error-messages">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Display Success Message -->
        <?php if(session('success')): ?>
            <div class="success-message">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(isset($games) && count($games) > 0): ?>
            <h2>Games for <?php echo e($player); ?></h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th> <!-- Added ID Column -->
                        <th>Black</th>
                        <th>White</th>
                        <th>Winner</th>
                        <th>Moves</th>
                        <th>Time Played</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $games; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $game): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($game->id); ?></td> <!-- Displaying ID -->
                            <td><?php echo e($game->black); ?></td>
                            <td><?php echo e($game->white); ?></td>
                            <td><?php echo e($game->winner); ?></td>
                            <td><?php echo e($game->moves); ?></td>
                            <td><?php echo e($game->created_at); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php elseif(isset($player)): ?>
            <p>No games found for player: <?php echo e($player); ?></p>
        <?php endif; ?>

        <h2>Add New Game</h2>
        <form action="<?php echo e(route('page1.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <input type="text" name="black" placeholder="Black player" required>
            <input type="text" name="white" placeholder="White player" required>
            <input type="text" name="winner" placeholder="Winner" required>
            <textarea name="moves" placeholder="Moves" required></textarea>
            <button type="submit">Add Game</button>
        </form>
    </div>
    <footer>
        <p>&copy; seppe's schaak app</p>
    </footer>
</body>
</html><?php /**PATH C:\chessApp\cloudtaak_chessapp\chess-app\resources\views/page1.blade.php ENDPATH**/ ?>