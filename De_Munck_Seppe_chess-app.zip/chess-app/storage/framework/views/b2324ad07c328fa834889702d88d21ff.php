<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Page 2 - Competition</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/styles.css')); ?>">
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #333;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        .error-messages {
            color: red;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <header>
        <h1>Chess App - Competition</h1>
    </header>
    <div class="container">
        <h2>Enter Players for Competition</h2>
        <form action="<?php echo e(route('page2')); ?>" method="GET">
            <?php echo csrf_field(); ?>
            <input type="text" name="players" placeholder="Enter player names, separated by commas" required>
            <button type="submit">Generate Matchups</button>
        </form>

        <!-- Display Error Messages -->
        <?php if($errors->any()): ?>
            <div class="error-messages">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>

        <!-- Display Rounds -->
        <?php if(isset($rounds) && count($rounds) > 0): ?>
            <?php $__currentLoopData = $rounds; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $round): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <h2>Round <?php echo e($round['round']); ?></h2>
                <table>
                    <thead>
                        <tr>
                            <th>Player 1</th>
                            <th>Player 2</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $round['matches']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($match[0]); ?></td>
                                <td><?php echo e($match[1]); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php elseif(isset($players)): ?>
            <p>No rounds found for players: <?php echo e($players); ?></p>
        <?php endif; ?>
    </div>
    <footer>
        <p>&copy; seppe's schaak app</p>
    </footer>
</body>
</html><?php /**PATH C:\chessApp\cloudtaak_chessapp\chess-app\resources\views/page2.blade.php ENDPATH**/ ?>